//
//  Question.swift
//  Quizzler
//
//  Created by Meet Thanki on 02/07/19.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import Foundation

class Question {
    
    
    let questiontext : String
    let answer : Bool
    
    
    init(text:String ,correctAnswer:Bool){
        questiontext=text
        answer=correctAnswer
    }
    
    
}
